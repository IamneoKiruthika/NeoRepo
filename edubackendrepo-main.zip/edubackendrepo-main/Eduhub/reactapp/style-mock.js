// style-mock.js
module.exports = {};
