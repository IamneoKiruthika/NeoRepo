
const API_BASE_URL = 'https://eduhubapp24.azurewebsites.net';

export default API_BASE_URL;
