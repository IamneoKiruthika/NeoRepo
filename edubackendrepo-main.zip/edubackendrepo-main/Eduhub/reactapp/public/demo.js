
[

  {

    "evaluation_type": "React Jest",

    "testcases": [

     {

        "name": "week4_day4_renders_adminpaymentscomponent_without_crashing",

        "weightage":0.03314

      },

      {

        "name": "week4_day4_check_for_presense_of_title_in_Order_billing",

        "weightage":0.03334

      },

      {

        "name": "week4_day4_test_case_for_rendering_orderspage__component",

        "weightage":0.03334

      },

      {

        "name": "week4_day4_checks_for_the_presence_of_color_property_in_inline_style",

        "weightage":0.03334

      },

      {

        "name": "week4_day4_checks_for_the_presence_of_backgroundcolor_property_in_inline_style",

        "weightage":0.03334

      },

      {

        "name": "week4_day4_checks_for_the_presence_of_borderradius_property_in_inline_style",

        "weightage":0.03334

      },

      {

        "name": "week4_day4_checks_for_the_presence_of_padding_property_in_inline_style",

        "weightage":0.03334

      },

      {

        "name": "week4_day5_testcase_to_check_the_rendering_of_forgotpassword_component",

        "weightage":0.03334

      },

      {

        "name": "week4_day5_testcase_for_initializing_state_for_storing_form_data_and_if_data_matching_with_regex",

        "weightage":0.03334

      },

      {

        "name": "week4_day5_testcase_for_error_states_if_the_value_is_empty",

        "weightage":0.03334

      },

      {

        "name": "week4_day5_testcase_for_error_states_if_the_value_is_invalid",

        "weightage":0.03334

      },

      {

        "name": "week5_day1_testcase_for_rendering_adminmenu_component_without_errors",

        "weightage":0.03334

      },

      {

        "name": "week5_day1_testcase_for_lazy_loading",

        "weightage":0.03334

      },

      {

        "name": "week5_day1_test_case_for_rendering_the_tableselection_component",

        "weightage":0.03334

      },

      {

        "name": "week5_day1_testcase_for_lifecycle_method_and_http_request",

        "weightage":0.03334

      },

      {

        "name": "week5_day1_testcase_for_data_fetched_in_lifecycle_method",

        "weightage":0.03334

      },

      {

        "name": "week5_day1_test_case_for_rendering_register_component",

        "weightage":0.03334

      },

      {

        "name": "week5_day1_test_case_for_navigating_to_login",

        "weightage":0.03334

      },

      {

        "name": "week5_day2_for_testing_action_type",

        "weightage":0.03334

      },

      {

        "name": "week5_day2_for_testing_action_payload",

        "weightage":0.03334

      },

      {

        "name": "week5_day2_for_testing_redux_state",

        "weightage":0.03334

      },

      {

        "name": "week5_day2_for_testing_component_rendering",

        "weightage":0.03334

      },

      {

        "name": "week5_day3_renders_admintable_component",

        "weightage":0.03334

      },

      {

        "name": "week5_day3_renders_the_component_and_fetches_table_data_and_checks_for_tableNo",

        "weightage":0.03334

      },

      {

        "name": "week5_day3_renders_the_component_and_fetches_table_data_and_checks_for_isavailable",

        "weightage":0.03334

      },

      {

        "name": "week5_day3_renders_the_component_and_fetches_table_data_and_checks_for_alloted",

        "weightage":0.03334

      },

      {

        "name": "week5_day4_rendering_login_component",

        "weightage":0.03334

      },

      {

        "name": "week5_day4_initializing_state_to_store_form_data_evaluate_inupt_data_using_regex",

        "weightage":0.03334

      },

      {

        "name": "week5_day4_testcase_for_error_states_if_the_value_is_empty",

        "weightage":0.03334

      },

      {

        "name": "week5_day4_testcase_for_error_states_if_the_value_is_invalid",

        "weightage":0.03334

      }

    ],

    "testcase_run_command": "sh /home/coder/project/workspace/react/react.sh",

    "testcase_path": "/home/coder/project/workspace/react"

  }

]