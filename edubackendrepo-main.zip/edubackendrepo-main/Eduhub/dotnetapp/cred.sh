#!/bin/bash

export AZURE_CLIENT_ID="c76580b8-4a15-4c2c-b82e-bd0e143705d6"
export AZURE_CLIENT_SECRET="u0Q8Q~C2L9nfkCxQ2pdJLQZr~aiDtEKhB-C~Qcbc"
export AZURE_TENANT_ID="38723e4f-6e87-4945-b844-2dfd53cabd17"
export AZURE_SUBSCRIPTION_ID="614ad733-4d6f-4b45-8c9a-0812b67403f7"


# Your script logic goes here
