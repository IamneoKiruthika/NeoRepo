﻿public class KeyVaultConfiguration
{
    public string URL { get; set; }
    public string ConnectionStringSecretName { get; set; }
    public string BlobSecret { get; set; }    
}
