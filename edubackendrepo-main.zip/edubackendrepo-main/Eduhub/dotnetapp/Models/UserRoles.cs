﻿namespace dotnetapp.Models
{
    public static class UserRoles
    {
        public const string Admin = "Student";

        public const string User = "Educator";
    }
}
